//
//  ViewController.swift
//  TheEventAPP
//
//  Created by Usuario invitado on 24/10/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var nomEvento: UILabel!
    var vieneDeAtras : eventos!
    var direccion: String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        nomEvento.text = vieneDeAtras.nombreEvento
        direccion = vieneDeAtras.direccionEvento
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "ParaMapa"{
            
            let destino = segue.destination as! MapaViewController
            destino.Direccion = direccion
            destino.NombreEvento = vieneDeAtras.nombreEvento
        }
    }
    
}

