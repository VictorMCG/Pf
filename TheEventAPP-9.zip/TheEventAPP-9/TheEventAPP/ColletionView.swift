//
//  ColletionView.swift
//  TheEventAPP
//
//  Created by Macbook on 11/20/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//

import Foundation
import UIKit




