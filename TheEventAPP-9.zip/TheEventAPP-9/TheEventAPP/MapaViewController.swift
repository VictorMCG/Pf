//
//  MapaViewController.swift
//  TheEventAPP
//
//  Created by Usuario invitado on 30/10/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//


import UIKit
import MapKit
import CoreLocation

class MapaViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate {
    
    
    @IBOutlet weak var mapita: MKMapView!
    
    @IBOutlet weak var Tipos: UISegmentedControl!
    let locationManager = CLLocationManager()
    var Direccion:String!
    var NombreEvento:String!

    override func viewDidLoad() {
        super.viewDidLoad()
        mapita.delegate = self
        locationManager.delegate = self
        
        locationManager.requestWhenInUseAuthorization()
        
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.distanceFilter = kCLDistanceFilterNone
        
        locationManager.startUpdatingLocation()
        mapita.showsUserLocation = true
        
        Tipos.addTarget(self, action: #selector(cambiarMapas), for: .valueChanged)
        
        
        
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        let annotation = EventAnotation()
        annotation.coordinate = CLLocationCoordinate2D(latitude: 37.33182, longitude: -122.406417)
        annotation.title = NombreEvento
        annotation.imageURL = "Final.png"
        mapita.addAnnotation(annotation)
        
        let region = MKCoordinateRegion(center: annotation.coordinate, span: MKCoordinateSpan(latitudeDelta: 0.0009, longitudeDelta: 0.0009))
        mapita.setRegion(region, animated: true)
    }
    
    
    
    
    @IBAction func cambiarMapas( segmentedControl: UISegmentedControl) {
        switch(segmentedControl.selectedSegmentIndex){
        case 0:
            mapita.mapType = .standard
        case 1:
            mapita.mapType = .satellite
        case 2:
            mapita.mapType = .hybrid
        default:
            mapita.mapType = .standard
        }
    }
    
    
    /*func mapView(_ mapView: MKMapView, didUpdate userLocation: MKUserLocation) {
        let region = MKCoordinateRegion(center: mapita.userLocation.coordinate , span: MKCoordinateSpan(latitudeDelta: 0.0009, longitudeDelta: 0.0009) )
        
        mapita.setRegion(region, animated: true)
    }*/
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        print(locations.first)
    }
    
    func mapView( mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        
        if annotation is MKUserLocation{
            return nil
        }
        
        var EventAnotationView = mapita.dequeueReusableAnnotationView(withIdentifier: "EventAnotationView")
        if EventAnotationView == nil{
            EventAnotationView = MKAnnotationView(annotation: annotation, reuseIdentifier: "EventAnotationView")
            
            EventAnotationView?.canShowCallout = true
        }else{
            EventAnotationView?.annotation = annotation
        }
        if let EventAnotation = annotation as? EventAnotation{
            
            EventAnotationView?.image = UIImage(named: EventAnotation.imageURL)
        }
        return EventAnotationView
    }
    
    
    

}

